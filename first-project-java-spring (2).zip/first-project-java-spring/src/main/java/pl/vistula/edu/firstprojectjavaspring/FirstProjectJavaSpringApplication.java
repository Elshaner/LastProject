package pl.vistula.edu.firstprojectjavaspring;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FirstProjectJavaSpringApplication {

	public static void main(String[] args) {
		SpringApplication.run(FirstProjectJavaSpringApplication.class, args);
	}

}
